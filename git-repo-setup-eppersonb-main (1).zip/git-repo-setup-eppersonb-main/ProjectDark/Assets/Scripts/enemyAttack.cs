﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyAttack : MonoBehaviour
{
    [SerializeField] float enemyDamage;
    public bool enemyHit = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 origin = transform.position;

        Vector3 direction = transform.forward;

        Ray ray = new Ray(origin, direction);

        Debug.DrawRay(origin, direction * 1.0f, Color.red);
        if (Physics.Raycast(ray, out RaycastHit raycastHit, 1.0f))
        {
            // Debug.Log("The light is hitting the enemy");
            playerMovement player = raycastHit.transform.GetComponent<playerMovement>();
            if (player!= null)
            {
                //Debug.Log("The light is hitting the enemy");
                player.playerHurt(enemyDamage);

                DestroyObject(gameObject);
            }

        }



    }
}
