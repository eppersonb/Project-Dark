﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightManipulationEvent : MonoBehaviour
{
    public Light lt;
    [SerializeField] float timer;
    public Color lightColor = Color.white;
    public bool safeHavenTouched;
    public float t;
    public string minutes = "0";
    public string seconds = "0";
    
    // Start is called before the first frame update
    void Start()
    {
        timer = Time.time;
        lt = GetComponent<Light>();
    }

    // Update is called once per frame
    void Update()
    {
        darkEvent();
    }

    private void darkEvent()
    {
        t = Time.time - timer;
        string minutes = ((int)t / 60).ToString();
        string seconds = (t % 60).ToString("f2");

        if (minutes == "0")
        {
           
            lt.color -= Color.white * Time.deltaTime;
        }

    }

    public void resetLight()
    {
        minutes = "0";
        lt.color = Color.white;
        Debug.Log("You made it to the light!");
    }
}
