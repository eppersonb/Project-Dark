﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class medKitCount : MonoBehaviour
{
    
    public static int medKitValue = 0;
    Text Medkit;

    // Start is called before the first frame update
    void Start()
    {
        Medkit = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        Medkit.text = "Medical Items:" + medKitValue;
    }
}
