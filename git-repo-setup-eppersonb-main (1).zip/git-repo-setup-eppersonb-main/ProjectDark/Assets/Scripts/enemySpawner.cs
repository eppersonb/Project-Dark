﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemySpawner : MonoBehaviour
{
    public GameObject enemy;
    public int xPosition;
    public int zPosition;
    public int enemyCounter;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(enemySpawn());
    }

    IEnumerator enemySpawn()
    {
        while (enemyCounter < 60)
        {
            xPosition = Random.Range(1, 45);
            zPosition = Random.Range(50, 50);
            Instantiate(enemy, new Vector3(xPosition, 2, zPosition), Quaternion.identity);
            yield return new WaitForSeconds(1f);
            enemyCounter += 1;
        }
    }

}
