﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gunController : MonoBehaviour
{
    public bool isFiring;

    public bulletController bullet;
    public float bulletSpeed;
    public float intervalBetweenShots;
    private float shotCounter;
    public Transform firingPoint;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        bulletFire();
    }

    private void bulletFire() // This function controls the gun, this uses a boolean to check to see if the gun is firing or not. If the gun is not firing reset the counter.
    {
        if (isFiring)
        {
            shotCounter -= Time.deltaTime;
            if (shotCounter <= 0)
            {
                shotCounter = intervalBetweenShots;
                bulletController newBullet = Instantiate(bullet, firingPoint.position, firingPoint.rotation) as bulletController;
                newBullet.speed = bulletSpeed;
            }
        }
        else
        {
            shotCounter = 0;
        }
    }
}
