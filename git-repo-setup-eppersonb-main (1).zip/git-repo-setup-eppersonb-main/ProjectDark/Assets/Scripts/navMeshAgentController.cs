﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class navMeshAgentController : MonoBehaviour
{
    // Start is called before the first frame update

    public bool canIMove;
    public GameObject Player;
    public GameObject thePlayer;

    void Start()
    {
        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("Player");
        foreach(GameObject go in gos)
        {
            thePlayer = go;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(canIMove == true)
        {
            GetComponent<NavMeshAgent>().SetDestination(thePlayer.transform.position);
        }
    }
}
