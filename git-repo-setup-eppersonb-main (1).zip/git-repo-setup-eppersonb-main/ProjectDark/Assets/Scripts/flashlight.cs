﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class flashlight : MonoBehaviour
{
    [SerializeField] private Color tintColor = Color.green;
    private Color enemyColor = Color.red;
    [SerializeField] float flashlightMagnitude = 10f;
    CharacterController enemyCharacter;
    [SerializeField] float flashlightDamage = 10f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        flashlightRay();
    }

    void flashlightRay()
    {
        Vector3 origin = transform.position;

        Vector3 direction = transform.right;

        Ray ray = new Ray(origin, direction);

        Debug.DrawRay(origin, direction * flashlightMagnitude, Color.red);
        if (Physics.Raycast(ray, out RaycastHit raycastHit, flashlightMagnitude))
        {
            // Debug.Log("The light is hitting the enemy");
            enemyBehavior enemy = raycastHit.transform.GetComponent<enemyBehavior>();
            if (enemy != null)
            {
                //Debug.Log("The light is hitting the enemy");
                enemy.recieveDamageToShroud(flashlightDamage);
            }
        }

    }
}
