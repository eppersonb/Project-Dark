﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playerMovement : MonoBehaviour
{
    CharacterController myCharacterController;
    private Camera mainCamera;
    [SerializeField] float playerMoveSpeed = 4.5f;
    [SerializeField] float turnSpeed = 4.5f;
    [SerializeField] float turnAngle;
    public float playerCurrentHealth, playerMaxHealth = 100;
    public Image healthBar;
    public float lerpSpeed;
    public gunController gun;
    public int healthItems = 0;
    AudioSource gunfireSource;
    // Start is called before the first frame update
    void Start()
    {
        medKitCount.medKitValue = healthItems;
        playerCurrentHealth = 100;
        gunfireSource = GetComponent<AudioSource>();
        myCharacterController = GetComponent<CharacterController>();
        mainCamera = FindObjectOfType<Camera>();
    }

    // Update is called once per frame
    void Update()
    {
        healthBarFiller();
        playerHealthColorChanger();
        playerMove();
        playerLook();
        gunControl();

        lerpSpeed = 3f * Time.deltaTime;
        if(Input.GetKey(KeyCode.C) && healthItems != 0 && playerCurrentHealth != 100)
        {
            playerCurrentHealth += (playerMaxHealth - playerCurrentHealth);
            healthItems -= 1;
        }
        if(playerCurrentHealth <= 0)
        {
            Destroy(gameObject);
        }
        medKitCount.medKitValue = healthItems;
    }

    public void healthBarFiller()
    {

        healthBar.fillAmount = Mathf.Lerp(healthBar.fillAmount, playerCurrentHealth / playerMaxHealth, lerpSpeed);

    }

    public void playerHealthColorChanger()
    {
        Color healthColor = Color.Lerp(Color.red, Color.green, (playerCurrentHealth / playerMaxHealth));
        healthBar.color = healthColor;
    }

    public void playerHurt(float amount)
    {
        playerCurrentHealth -= amount;

        Debug.Log("Player HURT!!!");
    }
    public void playerGrabHealth(int grabbed)
    {
        healthItems += grabbed;

        Debug.Log("Health Acquired");
    }
    private void gunControl()
    {
        if (Input.GetMouseButtonDown(0))
        {
            
            
            gunfireSource.Play();
            
            gun.isFiring = true;

        }
        if (Input.GetMouseButtonUp(0))
        {
            gun.isFiring = false;
        }
    }

    private void playerLook()
    {
        Ray cameraRay = mainCamera.ScreenPointToRay(Input.mousePosition); //This sends a ray to a new position pointing to where the mouse is in the game screen
        Plane groundPlane = new Plane(Vector3.up, Vector3.zero); // the ground plane for the cameraRay to point to.
        float rayLength;

        if (groundPlane.Raycast(cameraRay, out rayLength)) // this finds the point where the ray line intersects with the ground at the current time.
        {
            Vector3 pointToLook = cameraRay.GetPoint(rayLength); // this sets a point in space for the camera to look at
            // Debug.DrawLine(cameraRay.origin, pointToLook, Color.green);
            transform.LookAt(new Vector3(pointToLook.x, transform.position.y, pointToLook.z));
        }
    }

    private void playerMove()
    {
        if (Input.GetKey(KeyCode.W))
        {
            Vector3 forward = Vector3.forward;
            myCharacterController.Move(forward * playerMoveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.A))
        {
            Vector3 left = Vector3.left;
            myCharacterController.Move(left * playerMoveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.S))
        {
            Vector3 back = Vector3.back;
            myCharacterController.Move(back * playerMoveSpeed * Time.deltaTime);
            
        }
        if (Input.GetKey(KeyCode.D))
        {
            Vector3 right = Vector3.right;
            myCharacterController.Move(right * playerMoveSpeed * Time.deltaTime);
            
        }
    }
}
