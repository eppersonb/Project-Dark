﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyBehavior : MonoBehaviour
{
    public int enemyHealth = 10;
    private int currentHealth;
    [SerializeField] private Color enemyColor = Color.red;
    [SerializeField] private Color brokenShroud = Color.yellow;
    [SerializeField] ParticleSystem enemydeathParticle = null;
    CharacterController enemyCC;
    Collider enemyCollider;
    public float enemyShroud = 100f;
    Material enemyMaterial;
    public bool isShroudBroken = false;

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = enemyHealth;
        enemyCC = GetComponent<CharacterController>();
        enemyCollider = GetComponent<Collider>();
        enemyMaterial = GetComponent<MeshRenderer>().material;
    }

    // Update is called once per frame
    void Update()
    {

        if(currentHealth <= 0)
        {
            killCount.scoreValue += 1;
            Destroy(gameObject);
        }
        if(enemyShroud <= 100)
        {
            enemyShroud += 1;
        }
        if(enemyShroud >= 100 && isShroudBroken == true)
        {
            isShroudBroken = false;
            enemyMaterial.color = Color.red;
        }    
    }



    public void recieveDamageToShroud(float amount) // if enemy recieve flashlight damage and it less than zero, the enemy changes color
    {
        enemyShroud -= amount;

        if (enemyShroud <= 0f)
        {
            enemyMaterial.color = Color.yellow;
            isShroudBroken = true;
        }
    }
    public void damageEnemy(int damage)
    {
        if(isShroudBroken)
        {
            Debug.Log("ow");
            currentHealth -= damage;
        }
        else
        {
            Debug.Log("now ow");
        }
    }
}
