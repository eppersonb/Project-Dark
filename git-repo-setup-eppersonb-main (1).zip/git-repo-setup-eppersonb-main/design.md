Gameplay Loop
![gameplau loop](https://user-images.githubusercontent.com/42677445/140389493-dbb9fd75-b150-48e1-a567-80cc3bdc93c9.png)
Gameplay concept
![concept 1](https://user-images.githubusercontent.com/42677445/134120003-28c9ec0e-1c3d-4b42-8d5d-f7881814f6e5.jpg)
---------------------------------------------
The Pause Menu
![pause menu](https://user-images.githubusercontent.com/42677445/134120023-abc33a64-093d-428d-8037-cbe0e92042b1.jpg)
