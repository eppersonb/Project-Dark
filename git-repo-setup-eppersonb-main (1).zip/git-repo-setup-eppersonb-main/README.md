# Project: Dark

![In progress image](https://user-images.githubusercontent.com/42677445/137001718-68eebc3a-6192-40e2-a7ee-ab8419f3865a.png)

## [Concept](https://github.com/BC-senior-projects/git-repo-setup-eppersonb/blob/main/concept.md)


## Description/Motivation

Your formally written project proposal description, and why it is useful/interesting/fun goes here. Try to be as descriptive as possible, as we will be discussing your project ideas during the brainstorming in class.

So this game idea started when I was at my lowest point and I couldn't really function as a normal person. So my mind does what it does best and it just wonders and then it hit me with an idea. A top-down game where you use a flashlight to stave off the "darkness" and it serves as a methaphor to fighting off depression. I think this project will be useful in terms of giving an excuse to make something and learn some skills and continue develop my C# skills. So, the game is about fighting the darkness perse and your in a world where it looks normal to our own but there's a twist as you don't know who you are or why you here and you start to learn more about yourself as you play the game more. You get some useful tools that help you fight off the darkness such as flashbangs or floodlights. I also would like to implement like an AI director that controls the spawns of enemies and items so every playthrough will be unique. Of course your main tool is a flashlight and a gun and like elements to the game Alan Wake you use the light to break an enemies "shroud" before they can take full damage from your weapon. I've also thought of a cool gadget called "Light Rounds" where your ammunition becomes temporarily imbued with light so you can defeat enemies without having to break the shroud. Of course we need enemies and I have abunch of ideas but for now I have four enemies

* Dregde - These enemies serve as basic cannon fodder and serve to populate the level. They serve to take attention away from you from other baddies but luckily for you they have little to no "shroud" so you can easily dispatch them. Shining the light on them will either cause them to retreat or be blinded temporarily. However, dont let these guys mob you or you're not long for the new world.
* Redeemer - These freaks of nature are fast and typically one or two of them appears in a horde of dredges. They move fast and their arm-blades will make quick work of you if you're not paying attention. They have medium "shroud" but luckily for you shining a light on them will slow them down termendously, so keep your light handy or you might end up being ribbons.
* Wretch - These creatures prefer ranged engagements over close encounters. They will spit at the you from a distance to make sure you stay on your toes. However, they will retreat if you shine your light on them or get close to them as they don't like anything getting close to them. Luckily for you wretches have little shrouding so little firepower is required to take them down
* Brute - These hulking monstrosties require most if not all of your attention. They may not be fast but they can kill you if are not quick enough to doding their attacks. Don't assume your safe because you are at a distance however as they can grab some debris and hurl it towards and it will hurt just as bad. The brute is not meant to be a supreme challenge but to make sure the dredges and redeemers get to you. They have high amount of "Shroud" so you need some serious light sources to break it be it flashbangs, flares, or light rounds. Brutes can be killed from the front if their shroud is broken but however a skilled player can manuever behind the brute and shoot it in it's back for critical damage even if the brute still has the shroud.

Then there is you the main character which is Alice, a simple name for simple players like us. She serves as the game's main protagonist who has to find a way out of the world while confronting the monstronsties with her gun and a light. Luckily for you Alice is an artist so can draw maps and enemies and can give her opinion about the events of the game.

## Vision

Not much to say other than to make a game in my head that tries to be fun and tell a compelling story and hopefully help the player.

## Scope
I think the scope of this is a playable demo, like at least get one level done with a few combat encounters and at least introduce the player to the story and maybe get them invested in the full product. So for know we slowly build the game up from shapes and blocks to full 3d models. Right now I'm working on movement and player looking at the mouse.

### Prerequisites

For now I think I need unity and visual studio and some assets made for Project: Dark.

- [Requirments](https://github.com/BC-senior-projects/git-repo-setup-eppersonb/blob/main/requirements.md)
- [Design](https://github.com/BC-senior-projects/git-repo-setup-eppersonb/blob/main/design.md)

## Built With

This project will be builty with unity which uses C#
The IDE we will be using is Visual Studio 2019(The version I have).

## Author

- Bryan Epperson: Project: Dark [eppersonb](https://github.com/eppersonb)
## About Me
![about me](https://user-images.githubusercontent.com/42677445/136898721-418c8d96-79e0-43c0-a2af-9d2fcf7168b3.jpg)

Local Kentucktian from a town called Jenkins. I have played games since I was six years old sitting on my dad's lap. Ever since I watched a behind the scenes footage for Sly 2: Band of thieves it has inspired me to become a game developer.

## Acknowledgments

* Brackys - has alot of unity tutorials and really good.
* Dani - Inspired me to go out there develop my game
* Michal Murr - His unity tutorial was a great confidence builder and proved to me that I can code (https://www.udemy.com/course/ultimate-guide-to-c-unity-3d-learn-to-code-making-3d-game/)
- Inspirations: Alan Wake, Silent Hill, My friends from discord for allowing me to express the idea.
- I'll update as this goes as I get help from friends.
## Installation

[Installation](https://github.com/BC-senior-projects/git-repo-setup-eppersonb/blob/main/installation.md)

## Current State Of The Project
   - [Movement Prototype](https://www.youtube.com/watch?v=eUtbWoLpRgg)
   - [Flashlight damage to enemy](https://www.youtube.com/watch?v=185LWtbQ9Hc)
   - [Prototype gameplay](https://youtu.be/VrrtFjRQTrY)

## License (not required initially)

This project is licensed under the ??? License - see the wiki page (https://en.wikipedia.org/wiki/Software_license) for details

