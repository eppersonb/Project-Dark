<<<<<<< HEAD
* Step 1: Download Unity Hub
* Step 2: Create a folder to store a unity project
=======
* Step 1: Download the zip from this google drive link [https://drive.google.com/drive/folders/1RGqOAylCuSiBYgmMUnLwLVNeS-yLbV4e?usp=sharing]
* Step 2: Unzip the contents
* Step 3: Open the fine and the find the ProjectDark.exe
* Step 3: Run.exe
* Step 4: Enjoy

-------------------------------------------------------------------------------

Use this method if you have unity hub account

* Step 1: Click on this link to go to the project file.
* Step 2: Go to this link https://drive.google.com/drive/folders/16le71MTHN7axx2fdqQCF0vdoFAy9Z77k?usp=sharing
  * Step 2a: Download the file  
* Step 3: Unzip contents
* Step 4: Open unity hub
* Step 5: Click add
* Step 6: put the folder where you want to save the folder
* Step 7: add the project project fodler EX.(it doesn matter what the names of the folders are as long as your unity hub can find the path 
  - ![image](https://user-images.githubusercontent.com/42677445/144910629-1a72c821-1b0d-4886-a8c8-f88fe7d84e17.png)
* Step 8: Double click the project name and the game should run fine.


>>>>>>> e28b051ffee6bef5f2560977347a9b435ebe8f16
