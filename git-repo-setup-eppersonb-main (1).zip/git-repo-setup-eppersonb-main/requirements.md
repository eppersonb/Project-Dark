## Requirements
-------------------------------------------------------
* Number 1: The player has to be able to move and strafe
* Evaulation: This has already been completed
* Dependencies: NONE
* priority: 1
* Requirement Revision History: Already completed
--------------------------------------------------------
* Number 2: The player's flashight needs to be able to damage the enemy
* Evaluation: Being worked on, started working on a raycast that will collide with the enemy
* Dependcies: The players movement and strafing
* priorty: 2 
* Requirement Revision History: Done.
--------------------------------------------------------
* Number 2a: The player needs to be able to damage the enemy when the shroud is broken
* Evaluation: Being worked on now. 
* Dependecies: The flashlight mechanic needs to work.
* Priorty: 2
* Requirment Revision History: Done
--------------------------------------------------------
* Number 3: A level for the player to explore and play around
* Evaluation: This requirement will be satisfied once the gameplay mechanics are in play
* Dependcies: Gameplay mechanics are tuned and working along with enemies and items to populate the level
* priorty: 4
* Requirement Revision History: Done
--------------------------------------------------------
* Number 4: Enemies navagate the level and find the player or wander.
* Evaluation: This requirement will need to use unitys AI navMesh system.
* Dependcies:-
* priorty: 3
* Requirement Revision History: Done.
---------------------------------------------------------
* Number 4a: Enemies will have to states to the player in two states, wandering and attack when when spotted.
* Evaluation: To try to keep a dynamic pace in the game there will be enemies that wander into view and will attack the player when the player is spotted.         
  After the player is spotted the enemy will enter a chase state with the player and will pursue the player. The enemy will not rest until you are destroyed or the enemy is      destroyed. There will be events in the game where the enemies will automatically start combat with the player ignoring the wandering state.
* priority: 3
---------------------------------------------------------
* Number 4b: Enemies will attack the player via melee and range
* Evaluation: This will be done when the enemy is close than an animation will play which will shoot a ray cast to see if the enemys hit connected with the player. 
  The range enemies will spit projectiles so the player has a chance to avoid the range damage all together.
  priority: 3
  Revision history: This kinda works, although its wonky.
---------------------------------------------------------
* Number 5a: interactive objectives such as a keycard or a key needed to unlock doors
* Evaluation: This is interactive objectives to give the player to progress through the level. There will be an inventory for the player to hold these items. So for example if there is a locked door then the player will need a key and they will have to explore the level to find the key. there can also be a riddle a player needs to solve so it can unlock a door.
* Priority - 5
* Revision history: NEVER FINISHED.
---------------------------------------------------------
* Number 5b: interactive enviromental objects for the player to use.
* Evaluation: Somtimes the player needs to be creative, especially when hordes of enemies come into play. So spreading gas cans or maybe have flood lights that can turn on will get the player to interact with the map. 
* Priority - 5
* Revision history: NEVER FINISHED.
----------------------------------------------------------
* Number 6: A sandbox enviroment to test out mechanics and features as the game develops.
* Evaluation: This is a level in unity where mechanics can be tested
* Dependencies: None other than some models being made
* Priority: 4
  revision history: Done
----------------------------------------------------------
* Number 7: A mechanic where the player speed is affected by their current health
* Evaluation: This is a mechanic where the players speed will be affected by the state of their health. 100-65 percent of health the player moves at full speed, when the health is in range of 65 - 35 percent health the player will move at a moderate speed. When health is in the 35 - 1 percent of health range then the player will move at a crippling pace where the player's character will be limping to show that you the player are in need of attention.
* Dependencies: The players movement and a health system for the player
* priority 5: 
* * Revision history: DONE
----------------------------------------------------------
* Number 8: player health recovery
* Evaluation: The player must be able to have a way to recover their health. This can be done by health items such as first aid kits, Medic pack, bandages, or when entering a lighted area known as a "safe haven".
* Dependencies: Player attributes.
* priority: ...
-----------------------------------------------------------
* Number 9: Player holding down a key to sprint
* Evaluation: This is a mechanic where holding shift will momentarily increases the speed as they are holding down the shift key.
* Revision history: NEVER STARTED.
-----------------------------------------------------------
* Number 10: The ability for the player to pause, save, and exit the game.
* Evaluation: The player to pause the game to take a break and exit it as they wish. Also for them to save the game as well.
* Revision history: NEVER FINISHED. 
-------------------------------------------------------------
* Number 11: A weapon to fight off the enemy.
* Evaluation: weapons the player needs to fight off the enemy.
* Revision History:Done



