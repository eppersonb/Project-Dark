*[Movement prototype](https://www.youtube.com/watch?v=eUtbWoLpRgg&ab_channel=IoNicD3)
------------------------------------------------------------------------------------------------
*[Flashlight damage to enemy](https://www.youtube.com/watch?v=185LWtbQ9Hc)
*[Prototype gameplay](https://youtu.be/VrrtFjRQTrY)
