# CSC 493: Project Concept Proposal<sup>1</sup>

  - Project Name - Project:Dark
  - Goals - To create a game that is fun and tells a compelling story
  - Context - the context for my project is to help maybe jump start my carerr into game devlopment.
  - Novelty - I guess add the basics of movement and combat to gameplay
  - Functionality - the functionality at the moment is a like a gameplay demo. It will have some features and works it way up to a full game
  - Audience - Gamers and people who enjoy a slow thriller-horror genre
  - Challenges - Getting movement to work and the camera to point at the players mouse. Making the game enjoyable to play.
  - Measures - I don't know how to gauge this yet.
  - Motivation - My motivation comes from the game Alan Wake and my love for gaming. This game came to me when I was at my lowest point. I hope this will get me noticed in the game devlopement world.
  - Future Extensions - complex animations and improved gameplay as time goes by.
  - *Other (Optional)*


